<?php
include_once 'connection.php';
    $PstaffID = $_POST['PstaffID'];
    //$PcourID = $_POST['PcourID'];
    $COURIER_ID = mysqli_real_escape_string($con, $_POST['courier']);
        $PcourID = $COURIER_ID;
    $TN = $_POST['TN'];
    $Sname = $_POST['Sname'];
    $Sphonenumber= $_POST['Sphonenumber'];
    $Semail = $_POST['Semail'];
    $Saddress = $_POST['Saddress'];
    $Rname = $_POST['Rname'];
    $Rphonenumber = $_POST['Rphonenumber'];
    $Remail = $_POST['Remail'];
    $Raddress = $_POST['Raddress'];
    $weight = $_POST['weight'];
    $type = $_POST['type'];
    $cost= $_POST['cost'];
    $stats= $_POST['stats'];

    echo $PstaffID;
    echo $TN;
    echo $stats;

  
    $sql= "INSERT INTO parcel(parcel_staffID, parcel_courierID, parcel_trackingNumber, parcel_weight, parcel_type, parcel_totalPrice, parcel_status, parcelCustomer_name, parcelCustomer_phoneNumber, parcelCustomer_email, parcelCustomer_address, parcelRecipient_name, parcelRecipient_phoneNumber, parcelRecipient_email, parcelRecipient_address)
                VALUES ('$PstaffID','$PcourID','$TN','$weight','$type','$cost','$stats','$Sname','$Sphonenumber','$Semail','$Saddress','$Rname','$Rphonenumber','$Remail','$Raddress');";

        mysqli_query($con,$sql);
        header("Location:manageParcel.php?addParcel=success");
